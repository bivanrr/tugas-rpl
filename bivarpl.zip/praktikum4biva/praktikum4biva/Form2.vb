﻿Public Class Form2
    Private Sub btnHitung_Click(sender As Object, e As EventArgs) Handles btnHitung.Click
        Dim total As Integer =
            CInt(txtTotal.Text)
        Dim diskon As Integer = 0
        If total >= 100000 Then
            diskon = 40
        ElseIf total >= 50000 Then
            diskon = 15
        Else
            diskon = 0
        End If
        txtDiskon.Text = diskon & "%"
    End Sub
End Class