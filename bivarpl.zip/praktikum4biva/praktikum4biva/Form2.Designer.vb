﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnHitung = New Button()
        lblTotal = New Label()
        lblDiskon = New Label()
        txtTotal = New TextBox()
        txtDiskon = New TextBox()
        SuspendLayout()
        ' 
        ' btnHitung
        ' 
        btnHitung.Location = New Point(301, 127)
        btnHitung.Name = "btnHitung"
        btnHitung.Size = New Size(57, 36)
        btnHitung.TabIndex = 0
        btnHitung.Text = "Hitung"
        btnHitung.UseVisualStyleBackColor = True
        ' 
        ' lblTotal
        ' 
        lblTotal.AutoSize = True
        lblTotal.Location = New Point(243, 101)
        lblTotal.Name = "lblTotal"
        lblTotal.Size = New Size(33, 15)
        lblTotal.TabIndex = 1
        lblTotal.Text = "Total"
        ' 
        ' lblDiskon
        ' 
        lblDiskon.AutoSize = True
        lblDiskon.Location = New Point(243, 181)
        lblDiskon.Name = "lblDiskon"
        lblDiskon.Size = New Size(43, 15)
        lblDiskon.TabIndex = 2
        lblDiskon.Text = "Diskon"
        ' 
        ' txtTotal
        ' 
        txtTotal.Location = New Point(301, 98)
        txtTotal.Name = "txtTotal"
        txtTotal.Size = New Size(100, 23)
        txtTotal.TabIndex = 3
        ' 
        ' txtDiskon
        ' 
        txtDiskon.Location = New Point(301, 178)
        txtDiskon.Name = "txtDiskon"
        txtDiskon.Size = New Size(144, 23)
        txtDiskon.TabIndex = 4
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txtDiskon)
        Controls.Add(txtTotal)
        Controls.Add(lblDiskon)
        Controls.Add(lblTotal)
        Controls.Add(btnHitung)
        Name = "Form2"
        Text = "Form2"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnHitung As Button
    Friend WithEvents lblTotal As Label
    Friend WithEvents lblDiskon As Label
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents txtDiskon As TextBox
End Class
