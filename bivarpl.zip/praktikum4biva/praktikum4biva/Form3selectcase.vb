﻿Public Class Form3selectcase
    Private Sub btnCek_Click(sender As Object, e As EventArgs) Handles btnCek.Click
        Dim nilai As Integer =
            CInt(txtNilai.Text)
        Dim grade As String
        Select Case nilai
            Case >= 85
                grade = "A"
            Case >= 70
                grade = "B"
            Case >= 55
                grade = "C"
            Case Else
                grade = "D"
        End Select
        txtGrade.Text = grade
    End Sub
End Class