﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3selectcase
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblNilai = New Label()
        lblGrade = New Label()
        btnCek = New Button()
        txtNilai = New TextBox()
        txtGrade = New TextBox()
        SuspendLayout()
        ' 
        ' lblNilai
        ' 
        lblNilai.AutoSize = True
        lblNilai.Location = New Point(157, 135)
        lblNilai.Name = "lblNilai"
        lblNilai.Size = New Size(88, 15)
        lblNilai.TabIndex = 0
        lblNilai.Text = "Masukkan Nilai"
        ' 
        ' lblGrade
        ' 
        lblGrade.AutoSize = True
        lblGrade.Location = New Point(157, 238)
        lblGrade.Name = "lblGrade"
        lblGrade.Size = New Size(38, 15)
        lblGrade.TabIndex = 1
        lblGrade.Text = "Grade"
        ' 
        ' btnCek
        ' 
        btnCek.Location = New Point(217, 185)
        btnCek.Name = "btnCek"
        btnCek.Size = New Size(75, 23)
        btnCek.TabIndex = 2
        btnCek.Text = "Cek"
        btnCek.UseVisualStyleBackColor = True
        ' 
        ' txtNilai
        ' 
        txtNilai.Location = New Point(264, 132)
        txtNilai.Name = "txtNilai"
        txtNilai.Size = New Size(144, 23)
        txtNilai.TabIndex = 3
        ' 
        ' txtGrade
        ' 
        txtGrade.Location = New Point(217, 230)
        txtGrade.Name = "txtGrade"
        txtGrade.Size = New Size(199, 23)
        txtGrade.TabIndex = 4
        ' 
        ' Form3selectcase
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txtGrade)
        Controls.Add(txtNilai)
        Controls.Add(btnCek)
        Controls.Add(lblGrade)
        Controls.Add(lblNilai)
        Name = "Form3selectcase"
        Text = "Form3selectcase"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblNilai As Label
    Friend WithEvents lblGrade As Label
    Friend WithEvents btnCek As Button
    Friend WithEvents txtNilai As TextBox
    Friend WithEvents txtGrade As TextBox
End Class
