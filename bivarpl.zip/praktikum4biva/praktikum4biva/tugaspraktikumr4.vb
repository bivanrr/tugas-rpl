﻿Public Class tugaspraktikumr4
    Private Sub btnHitung_Click(sender As Object, e As EventArgs) Handles btnHitung.Click
        Dim harga As Integer = CInt(txtHarga.Text)
        Dim diskon As Integer = CInt(txtDiskon.Text)
        Dim hargaAkhir As Double = harga - (harga * diskon / 100)
        txtAkhir.Text = hargaAkhir
        If diskon >= 20 Then
            txtKeterangan.Text = "Diskon Spesial"
        ElseIf diskon >= 10 Then
            txtKeterangan.Text = "Diskon Menengah"
        Else
            txtKeterangan.Text = "Diskon Kecil"
        End If
    End Sub
End Class