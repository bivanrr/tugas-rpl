﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        btnCek = New Button()
        lblUmur = New Label()
        lblHasil = New Label()
        txtumur = New TextBox()
        txtHasil = New TextBox()
        SuspendLayout()
        ' 
        ' btnCek
        ' 
        btnCek.Location = New Point(279, 173)
        btnCek.Name = "btnCek"
        btnCek.Size = New Size(75, 23)
        btnCek.TabIndex = 0
        btnCek.Text = "Cek"
        btnCek.UseVisualStyleBackColor = True
        ' 
        ' lblUmur
        ' 
        lblUmur.AutoSize = True
        lblUmur.Location = New Point(214, 129)
        lblUmur.Name = "lblUmur"
        lblUmur.Size = New Size(94, 15)
        lblUmur.TabIndex = 1
        lblUmur.Text = "Masukkan Umur"
        ' 
        ' lblHasil
        ' 
        lblHasil.AutoSize = True
        lblHasil.Location = New Point(214, 219)
        lblHasil.Name = "lblHasil"
        lblHasil.Size = New Size(33, 15)
        lblHasil.TabIndex = 2
        lblHasil.Text = "Hasil"
        ' 
        ' txtumur
        ' 
        txtumur.Location = New Point(323, 126)
        txtumur.Name = "txtumur"
        txtumur.Size = New Size(100, 23)
        txtumur.TabIndex = 3
        ' 
        ' txtHasil
        ' 
        txtHasil.Location = New Point(264, 216)
        txtHasil.Name = "txtHasil"
        txtHasil.Size = New Size(159, 23)
        txtHasil.TabIndex = 4
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txtHasil)
        Controls.Add(txtumur)
        Controls.Add(lblHasil)
        Controls.Add(lblUmur)
        Controls.Add(btnCek)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnCek As Button
    Friend WithEvents lblUmur As Label
    Friend WithEvents lblHasil As Label
    Friend WithEvents txtumur As TextBox
    Friend WithEvents txtHasil As TextBox
End Class
