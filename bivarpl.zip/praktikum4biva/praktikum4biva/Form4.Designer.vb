﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnCek = New Button()
        lblAngka = New Label()
        lblHasil = New Label()
        txtAngka = New TextBox()
        txtHasil = New TextBox()
        SuspendLayout()
        ' 
        ' btnCek
        ' 
        btnCek.Location = New Point(233, 166)
        btnCek.Name = "btnCek"
        btnCek.Size = New Size(69, 35)
        btnCek.TabIndex = 0
        btnCek.Text = "cek"
        btnCek.UseVisualStyleBackColor = True
        ' 
        ' lblAngka
        ' 
        lblAngka.AutoSize = True
        lblAngka.Location = New Point(170, 140)
        lblAngka.Name = "lblAngka"
        lblAngka.Size = New Size(98, 15)
        lblAngka.TabIndex = 1
        lblAngka.Text = "Masukkan Angka"
        ' 
        ' lblHasil
        ' 
        lblHasil.AutoSize = True
        lblHasil.Location = New Point(170, 227)
        lblHasil.Name = "lblHasil"
        lblHasil.Size = New Size(33, 15)
        lblHasil.TabIndex = 2
        lblHasil.Text = "Hasil"
        ' 
        ' txtAngka
        ' 
        txtAngka.Location = New Point(283, 137)
        txtAngka.Name = "txtAngka"
        txtAngka.Size = New Size(100, 23)
        txtAngka.TabIndex = 3
        ' 
        ' txtHasil
        ' 
        txtHasil.Location = New Point(221, 224)
        txtHasil.Name = "txtHasil"
        txtHasil.Size = New Size(162, 23)
        txtHasil.TabIndex = 4
        ' 
        ' Form4
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txtHasil)
        Controls.Add(txtAngka)
        Controls.Add(lblHasil)
        Controls.Add(lblAngka)
        Controls.Add(btnCek)
        Name = "Form4"
        Text = "Form4"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnCek As Button
    Friend WithEvents lblAngka As Label
    Friend WithEvents lblHasil As Label
    Friend WithEvents txtAngka As TextBox
    Friend WithEvents txtHasil As TextBox
End Class
