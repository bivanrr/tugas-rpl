﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class tugaspraktikumr4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnHitung = New Button()
        lblBarang = New Label()
        lblAkhir = New Label()
        lblDiskon = New Label()
        txtHarga = New TextBox()
        txtAkhir = New TextBox()
        txtDiskon = New TextBox()
        txtKeterangan = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        lblKeterangan = New Label()
        SuspendLayout()
        ' 
        ' btnHitung
        ' 
        btnHitung.Location = New Point(303, 264)
        btnHitung.Name = "btnHitung"
        btnHitung.Size = New Size(75, 23)
        btnHitung.TabIndex = 0
        btnHitung.Text = "Hitung"
        btnHitung.UseVisualStyleBackColor = True
        ' 
        ' lblBarang
        ' 
        lblBarang.AutoSize = True
        lblBarang.Location = New Point(126, 169)
        lblBarang.Name = "lblBarang"
        lblBarang.Size = New Size(79, 15)
        lblBarang.TabIndex = 1
        lblBarang.Text = "Harga Barang"
        ' 
        ' lblAkhir
        ' 
        lblAkhir.AutoSize = True
        lblAkhir.Location = New Point(126, 218)
        lblAkhir.Name = "lblAkhir"
        lblAkhir.Size = New Size(70, 15)
        lblAkhir.TabIndex = 2
        lblAkhir.Text = "Harga Akhir"
        ' 
        ' lblDiskon
        ' 
        lblDiskon.AutoSize = True
        lblDiskon.Location = New Point(356, 169)
        lblDiskon.Name = "lblDiskon"
        lblDiskon.Size = New Size(43, 15)
        lblDiskon.TabIndex = 3
        lblDiskon.Text = "Diskon"
        ' 
        ' txtHarga
        ' 
        txtHarga.Location = New Point(218, 166)
        txtHarga.Name = "txtHarga"
        txtHarga.Size = New Size(100, 23)
        txtHarga.TabIndex = 4
        ' 
        ' txtAkhir
        ' 
        txtAkhir.Location = New Point(218, 215)
        txtAkhir.Name = "txtAkhir"
        txtAkhir.Size = New Size(100, 23)
        txtAkhir.TabIndex = 5
        ' 
        ' txtDiskon
        ' 
        txtDiskon.Location = New Point(417, 166)
        txtDiskon.Name = "txtDiskon"
        txtDiskon.Size = New Size(100, 23)
        txtDiskon.TabIndex = 6
        ' 
        ' txtKeterangan
        ' 
        txtKeterangan.Location = New Point(431, 215)
        txtKeterangan.Name = "txtKeterangan"
        txtKeterangan.Size = New Size(120, 23)
        txtKeterangan.TabIndex = 7
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(358, 223)
        Label1.Name = "Label1"
        Label1.Size = New Size(0, 15)
        Label1.TabIndex = 8
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(378, 230)
        Label2.Name = "Label2"
        Label2.Size = New Size(0, 15)
        Label2.TabIndex = 9
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(370, 219)
        Label3.Name = "Label3"
        Label3.Size = New Size(0, 15)
        Label3.TabIndex = 10
        ' 
        ' lblKeterangan
        ' 
        lblKeterangan.AutoSize = True
        lblKeterangan.Location = New Point(358, 218)
        lblKeterangan.Name = "lblKeterangan"
        lblKeterangan.Size = New Size(67, 15)
        lblKeterangan.TabIndex = 11
        lblKeterangan.Text = "Keterangan"
        ' 
        ' tugaspraktikumr4
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(lblKeterangan)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(txtKeterangan)
        Controls.Add(txtDiskon)
        Controls.Add(txtAkhir)
        Controls.Add(txtHarga)
        Controls.Add(lblDiskon)
        Controls.Add(lblAkhir)
        Controls.Add(lblBarang)
        Controls.Add(btnHitung)
        Name = "tugaspraktikumr4"
        Text = "tugaspraktikumr4"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnHitung As Button
    Friend WithEvents lblBarang As Label
    Friend WithEvents lblAkhir As Label
    Friend WithEvents lblDiskon As Label
    Friend WithEvents txtHarga As TextBox
    Friend WithEvents txtAkhir As TextBox
    Friend WithEvents txtDiskon As TextBox
    Friend WithEvents txtKeterangan As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblKeterangan As Label
End Class
