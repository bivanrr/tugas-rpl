﻿Public Class Form1
    Private Sub btnCek_Click(sender As Object, e As EventArgs) Handles btnCek.Click
        Dim umur As Integer =
            CInt(txtumur.Text)
        If umur >= 17 Then
            txtHasil.Text = "Dewasa"
        Else
            txtHasil.Text = "Belum Dewasa"
        End If
    End Sub
End Class
