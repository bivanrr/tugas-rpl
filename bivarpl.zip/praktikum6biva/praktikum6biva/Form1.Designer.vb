﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        btnProses = New Button()
        lstHasil = New ListBox()
        lblAngka = New Label()
        txtAngka = New TextBox()
        SuspendLayout()
        ' 
        ' btnProses
        ' 
        btnProses.Location = New Point(301, 153)
        btnProses.Name = "btnProses"
        btnProses.Size = New Size(75, 23)
        btnProses.TabIndex = 0
        btnProses.Text = "Proses"
        btnProses.UseVisualStyleBackColor = True
        ' 
        ' lstHasil
        ' 
        lstHasil.FormattingEnabled = True
        lstHasil.ItemHeight = 15
        lstHasil.Location = New Point(254, 191)
        lstHasil.Name = "lstHasil"
        lstHasil.Size = New Size(204, 49)
        lstHasil.TabIndex = 1
        ' 
        ' lblAngka
        ' 
        lblAngka.AutoSize = True
        lblAngka.Location = New Point(254, 122)
        lblAngka.Name = "lblAngka"
        lblAngka.Size = New Size(98, 15)
        lblAngka.TabIndex = 2
        lblAngka.Text = "Masukkan Angka"
        ' 
        ' txtAngka
        ' 
        txtAngka.Location = New Point(358, 114)
        txtAngka.Name = "txtAngka"
        txtAngka.Size = New Size(100, 23)
        txtAngka.TabIndex = 3
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txtAngka)
        Controls.Add(lblAngka)
        Controls.Add(lstHasil)
        Controls.Add(btnProses)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnProses As Button
    Friend WithEvents lstHasil As ListBox
    Friend WithEvents lblAngka As Label
    Friend WithEvents txtAngka As TextBox
End Class
