﻿Public Class Tugas4
    Private Sub btnBintang_Click(sender As Object, e As EventArgs) Handles btnBintang.Click
        lstHasil.Items.Clear()

        For i As Integer = 1 To 5
            Dim baris As String = ""

            For j As Integer = 1 To i
                baris &= "* "
            Next

            lstHasil.Items.Add(baris)
        Next
    End Sub
End Class