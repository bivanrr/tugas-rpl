﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Tugas3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnFibonacci = New Button()
        lstHasil = New ListBox()
        SuspendLayout()
        ' 
        ' btnFibonacci
        ' 
        btnFibonacci.Location = New Point(338, 193)
        btnFibonacci.Name = "btnFibonacci"
        btnFibonacci.Size = New Size(75, 23)
        btnFibonacci.TabIndex = 0
        btnFibonacci.Text = "Button1"
        btnFibonacci.UseVisualStyleBackColor = True
        ' 
        ' lstHasil
        ' 
        lstHasil.FormattingEnabled = True
        lstHasil.ItemHeight = 15
        lstHasil.Location = New Point(329, 239)
        lstHasil.Name = "lstHasil"
        lstHasil.Size = New Size(120, 94)
        lstHasil.TabIndex = 1
        ' 
        ' Tugas3
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(lstHasil)
        Controls.Add(btnFibonacci)
        Name = "Tugas3"
        Text = "Tugas3"
        ResumeLayout(False)
    End Sub

    Friend WithEvents btnFibonacci As Button
    Friend WithEvents lstHasil As ListBox
End Class
