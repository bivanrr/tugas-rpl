﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Tugas4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnBintang = New Button()
        lstHasil = New ListBox()
        SuspendLayout()
        ' 
        ' btnBintang
        ' 
        btnBintang.Location = New Point(380, 218)
        btnBintang.Name = "btnBintang"
        btnBintang.Size = New Size(75, 23)
        btnBintang.TabIndex = 0
        btnBintang.Text = "Button1"
        btnBintang.UseVisualStyleBackColor = True
        ' 
        ' lstHasil
        ' 
        lstHasil.FormattingEnabled = True
        lstHasil.ItemHeight = 15
        lstHasil.Location = New Point(360, 247)
        lstHasil.Name = "lstHasil"
        lstHasil.Size = New Size(120, 94)
        lstHasil.TabIndex = 1
        ' 
        ' Tugas4
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(lstHasil)
        Controls.Add(btnBintang)
        Name = "Tugas4"
        Text = "Tugas4"
        ResumeLayout(False)
    End Sub

    Friend WithEvents btnBintang As Button
    Friend WithEvents lstHasil As ListBox
End Class
