﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Tugas2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnJumlah = New Button()
        SuspendLayout()
        ' 
        ' btnJumlah
        ' 
        btnJumlah.Location = New Point(333, 217)
        btnJumlah.Name = "btnJumlah"
        btnJumlah.Size = New Size(75, 23)
        btnJumlah.TabIndex = 0
        btnJumlah.Text = "Jumlah"
        btnJumlah.UseVisualStyleBackColor = True
        ' 
        ' Tugas2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(btnJumlah)
        Name = "Tugas2"
        Text = "Tugas2"
        ResumeLayout(False)
    End Sub

    Friend WithEvents btnJumlah As Button
End Class
