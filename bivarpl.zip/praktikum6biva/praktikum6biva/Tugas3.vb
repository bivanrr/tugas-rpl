﻿Public Class Tugas3
    Private Sub btnFibonacci_Click(sender As Object, e As EventArgs) Handles btnFibonacci.Click
        lstHasil.Items.Clear()

        Dim a As Integer = 0
        Dim b As Integer = 1
        Dim c As Integer

        For i As Integer = 1 To 10
            lstHasil.Items.Add(a)

            c = a + b
            a = b
            b = c
        Next
    End Sub
End Class