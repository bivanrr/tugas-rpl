﻿Public Class Tugas2
    Private Sub btnJumlah_Click(sender As Object, e As EventArgs) Handles btnJumlah.Click
        Dim angka As Integer
        Dim total As Integer = 0

        Do
            angka = Val(InputBox("Masukkan angka (0 untuk berhenti):"))
            total += angka
        Loop While angka <> 0

        MessageBox.Show("Total penjumlahan = " & total)
    End Sub
End Class