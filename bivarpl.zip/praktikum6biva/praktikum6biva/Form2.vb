﻿Public Class Form2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim passwordBenar As String = "vbnet123"
        Dim percobaan As Integer = 0
        Dim berhasil As Boolean = False

        Do While percobaan < 3 And Not berhasil
            Dim input As String = InputBox(
                "Masukkan password (percobaan ke-" & (percobaan + 1) & " dari 3):")
            percobaan += 1

            If input = passwordBenar Then
                berhasil = True
                MessageBox.Show("Login Berhasil")
            ElseIf percobaan < 3 Then
                MessageBox.Show("Password Salah. Sisa percobaan: " & (3 - percobaan))
            Else
                MessageBox.Show(" Anda salah memasukkan password 3 kali. Aplikasi terkunci!")
            End If
        Loop

        If Not berhasil Then
            Application.Exit()
        End If
    End Sub
End Class