﻿Public Class Form1
    Private Sub btnHitung_Click(sender As Object, e As EventArgs) Handles btnHitung.Click
        Dim inputPKP As String = txtPKP.Text
        Dim pkp As Double
        Dim pajak As Double = 0

        If String.IsNullOrWhiteSpace(inputPKP) OrElse Not Double.TryParse(inputPKP, pkp) Then
            MessageBox.Show("Pesan Kesalahan: PKP yang diinput kosong atau bukan angka yang valid!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        If pkp < 0 Then
            MessageBox.Show("Pesan Kesalahan: PKP tidak boleh negatif!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        If pkp <= 60000000 Then
            pajak = pkp * 0.05
        ElseIf pkp <= 250000000 Then
            pajak = (60000000 * 0.05) + ((pkp - 60000000) * 0.15)
        ElseIf pkp <= 500000000 Then
            pajak = (60000000 * 0.05) + (190000000 * 0.15) + ((pkp - 250000000) * 0.25)
        Else
            pajak = (60000000 * 0.05) + (190000000 * 0.15) + (250000000 * 0.25) + ((pkp - 500000000) * 0.3)
        End If

        lblHasil.Text = $"Total Pajak Progresif: Rp{pajak:N0}"
    End Sub
End Class
