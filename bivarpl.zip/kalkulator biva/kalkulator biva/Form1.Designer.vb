﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        btnTambah = New Button()
        btnKurang = New Button()
        btnKali = New Button()
        btnBagi = New Button()
        txtAngka1 = New TextBox()
        txtAngka2 = New TextBox()
        txtHasil = New TextBox()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(178, 58)
        Label1.Name = "Label1"
        Label1.Size = New Size(88, 15)
        Label1.TabIndex = 0
        Label1.Text = "Angka Pertama"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(178, 104)
        Label2.Name = "Label2"
        Label2.Size = New Size(77, 15)
        Label2.TabIndex = 1
        Label2.Text = "Angka Kedua"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(178, 218)
        Label3.Name = "Label3"
        Label3.Size = New Size(33, 15)
        Label3.TabIndex = 2
        Label3.Text = "Hasil"
        ' 
        ' btnTambah
        ' 
        btnTambah.Location = New Point(178, 154)
        btnTambah.Name = "btnTambah"
        btnTambah.Size = New Size(64, 43)
        btnTambah.TabIndex = 3
        btnTambah.Text = "+"
        btnTambah.UseVisualStyleBackColor = True
        ' 
        ' btnKurang
        ' 
        btnKurang.Location = New Point(248, 154)
        btnKurang.Name = "btnKurang"
        btnKurang.Size = New Size(64, 43)
        btnKurang.TabIndex = 4
        btnKurang.Text = "-"
        btnKurang.UseVisualStyleBackColor = True
        ' 
        ' btnKali
        ' 
        btnKali.Location = New Point(318, 154)
        btnKali.Name = "btnKali"
        btnKali.Size = New Size(64, 43)
        btnKali.TabIndex = 5
        btnKali.Text = "X"
        btnKali.UseVisualStyleBackColor = True
        ' 
        ' btnBagi
        ' 
        btnBagi.Location = New Point(388, 154)
        btnBagi.Name = "btnBagi"
        btnBagi.Size = New Size(61, 43)
        btnBagi.TabIndex = 6
        btnBagi.Text = "/"
        btnBagi.UseVisualStyleBackColor = True
        ' 
        ' txtAngka1
        ' 
        txtAngka1.Location = New Point(296, 55)
        txtAngka1.Name = "txtAngka1"
        txtAngka1.Size = New Size(153, 23)
        txtAngka1.TabIndex = 7
        ' 
        ' txtAngka2
        ' 
        txtAngka2.Location = New Point(296, 101)
        txtAngka2.Name = "txtAngka2"
        txtAngka2.Size = New Size(153, 23)
        txtAngka2.TabIndex = 8
        ' 
        ' txtHasil
        ' 
        txtHasil.Location = New Point(217, 215)
        txtHasil.Name = "txtHasil"
        txtHasil.Size = New Size(232, 23)
        txtHasil.TabIndex = 9
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txtHasil)
        Controls.Add(txtAngka2)
        Controls.Add(txtAngka1)
        Controls.Add(btnBagi)
        Controls.Add(btnKali)
        Controls.Add(btnKurang)
        Controls.Add(btnTambah)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btnTambah As Button
    Friend WithEvents btnKurang As Button
    Friend WithEvents btnKali As Button
    Friend WithEvents btnBagi As Button
    Friend WithEvents txtAngka1 As TextBox
    Friend WithEvents txtAngka2 As TextBox
    Friend WithEvents txtHasil As TextBox
End Class
