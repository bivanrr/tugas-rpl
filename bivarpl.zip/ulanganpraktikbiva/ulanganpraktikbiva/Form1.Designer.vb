﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        btnCek = New Button()
        cmbKendaraan = New ComboBox()
        lnlKendaraan = New Label()
        txtWaktu = New TextBox()
        Label2 = New Label()
        lblHasil = New Label()
        SuspendLayout()
        ' 
        ' btnCek
        ' 
        btnCek.Location = New Point(241, 178)
        btnCek.Name = "btnCek"
        btnCek.Size = New Size(70, 30)
        btnCek.TabIndex = 0
        btnCek.Text = "Cek"
        btnCek.UseVisualStyleBackColor = True
        ' 
        ' cmbKendaraan
        ' 
        cmbKendaraan.FormattingEnabled = True
        cmbKendaraan.Location = New Point(283, 88)
        cmbKendaraan.Name = "cmbKendaraan"
        cmbKendaraan.Size = New Size(170, 23)
        cmbKendaraan.TabIndex = 1
        ' 
        ' lnlKendaraan
        ' 
        lnlKendaraan.AutoSize = True
        lnlKendaraan.Location = New Point(186, 88)
        lnlKendaraan.Name = "lnlKendaraan"
        lnlKendaraan.Size = New Size(91, 15)
        lnlKendaraan.TabIndex = 2
        lnlKendaraan.Text = "Jenis Kendaraan"
        ' 
        ' txtWaktu
        ' 
        txtWaktu.Location = New Point(279, 131)
        txtWaktu.Name = "txtWaktu"
        txtWaktu.Size = New Size(174, 23)
        txtWaktu.TabIndex = 3
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(186, 131)
        Label2.Name = "Label2"
        Label2.Size = New Size(74, 15)
        Label2.TabIndex = 5
        Label2.Text = "Waktu Parkir"
        ' 
        ' lblHasil
        ' 
        lblHasil.AutoSize = True
        lblHasil.Location = New Point(186, 241)
        lblHasil.Name = "lblHasil"
        lblHasil.Size = New Size(33, 15)
        lblHasil.TabIndex = 6
        lblHasil.Text = "Hasil"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(lblHasil)
        Controls.Add(Label2)
        Controls.Add(txtWaktu)
        Controls.Add(lnlKendaraan)
        Controls.Add(cmbKendaraan)
        Controls.Add(btnCek)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnCek As Button
    Friend WithEvents cmbKendaraan As ComboBox
    Friend WithEvents lnlKendaraan As Label
    Friend WithEvents txtWaktu As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents lblHasil As Label
End Class
