﻿Public Class Form1
    Private Sub btnCek_Click(sender As Object, e As EventArgs) Handles btnCek.Click
        Dim waktuparkir As Decimal
        Dim hasil As Integer

        If Not Decimal.TryParse(txtWaktu.Text, waktuparkir) Then
            MessageBox.Show("Masukkan angka!")
            Exit Sub
        End If

        If cmbKendaraan.Text = "Motor" Then

            If waktuparkir <= 1 Then
                hasil = 2000
            Else
                hasil = 2000 + CInt((waktuparkir - 1) * 1000)
            End If

        ElseIf cmbKendaraan.Text = "Mobil" Then

            If waktuparkir <= 1 Then
                hasil = 5000
            Else
                hasil = 5000 + CInt((waktuparkir - 1) * 2000)
            End If

        Else

            MessageBox.Show("Pilih kendaraan!")
            Exit Sub

        End If

        lblHasil.Text = "Total: Rp" & hasil.ToString("N0")
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbKendaraan.Items.Add("Mobil")
        cmbKendaraan.Items.Add("Motor")
    End Sub
End Class
