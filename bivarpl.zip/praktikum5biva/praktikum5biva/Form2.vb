﻿Public Class Form2
    Private Sub btnHitung_Click(sender As Object, e As EventArgs) Handles btnHitung.Click
        Dim celsius As Double
        Dim fahrenheit As Double

        Try
            If Not Double.TryParse(txtCelcius.Text, celsius) Then
                MessageBox.Show("Suhu Celsius harus berupa angka!",
                            "Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
                Return
            End If

            fahrenheit = (celsius * 9 / 5) + 32

            lblHasil.Text = "Fahrenheit: " & fahrenheit

        Catch ex As Exception
            MessageBox.Show("Terjadi kesalahan: " & ex.Message,
                        "Error",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error)

        Finally
            MessageBox.Show("Proses konversi selesai.",
                        "Info",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information)
        End Try
    End Sub
End Class