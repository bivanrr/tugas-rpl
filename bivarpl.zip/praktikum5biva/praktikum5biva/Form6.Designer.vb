﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        lblNama = New Label()
        lblNisn = New Label()
        lblUsia = New Label()
        lblEmail = New Label()
        btnDaftar = New Button()
        txtNama = New TextBox()
        txtNisn = New TextBox()
        txtUsia = New TextBox()
        txtEmail = New TextBox()
        ErrorProvider1 = New ErrorProvider(components)
        CType(ErrorProvider1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblNama
        ' 
        lblNama.AutoSize = True
        lblNama.Location = New Point(339, 109)
        lblNama.Name = "lblNama"
        lblNama.Size = New Size(39, 15)
        lblNama.TabIndex = 0
        lblNama.Text = "Nama"
        ' 
        ' lblNisn
        ' 
        lblNisn.AutoSize = True
        lblNisn.Location = New Point(339, 138)
        lblNisn.Name = "lblNisn"
        lblNisn.Size = New Size(31, 15)
        lblNisn.TabIndex = 1
        lblNisn.Text = "Nisn"
        ' 
        ' lblUsia
        ' 
        lblUsia.AutoSize = True
        lblUsia.Location = New Point(339, 167)
        lblUsia.Name = "lblUsia"
        lblUsia.Size = New Size(29, 15)
        lblUsia.TabIndex = 2
        lblUsia.Text = "Usia"
        ' 
        ' lblEmail
        ' 
        lblEmail.AutoSize = True
        lblEmail.Location = New Point(339, 196)
        lblEmail.Name = "lblEmail"
        lblEmail.Size = New Size(39, 15)
        lblEmail.TabIndex = 3
        lblEmail.Text = "Email "
        ' 
        ' btnDaftar
        ' 
        btnDaftar.Location = New Point(390, 232)
        btnDaftar.Name = "btnDaftar"
        btnDaftar.Size = New Size(75, 23)
        btnDaftar.TabIndex = 4
        btnDaftar.Text = "Daftar"
        btnDaftar.UseVisualStyleBackColor = True
        ' 
        ' txtNama
        ' 
        txtNama.Location = New Point(413, 106)
        txtNama.Name = "txtNama"
        txtNama.Size = New Size(129, 23)
        txtNama.TabIndex = 5
        ' 
        ' txtNisn
        ' 
        txtNisn.Location = New Point(413, 135)
        txtNisn.Name = "txtNisn"
        txtNisn.Size = New Size(129, 23)
        txtNisn.TabIndex = 6
        ' 
        ' txtUsia
        ' 
        txtUsia.Location = New Point(413, 164)
        txtUsia.Name = "txtUsia"
        txtUsia.Size = New Size(129, 23)
        txtUsia.TabIndex = 7
        ' 
        ' txtEmail
        ' 
        txtEmail.Location = New Point(413, 193)
        txtEmail.Name = "txtEmail"
        txtEmail.Size = New Size(129, 23)
        txtEmail.TabIndex = 8
        ' 
        ' ErrorProvider1
        ' 
        ErrorProvider1.ContainerControl = Me
        ' 
        ' tugaspraktik
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txtEmail)
        Controls.Add(txtUsia)
        Controls.Add(txtNisn)
        Controls.Add(txtNama)
        Controls.Add(btnDaftar)
        Controls.Add(lblEmail)
        Controls.Add(lblUsia)
        Controls.Add(lblNisn)
        Controls.Add(lblNama)
        Name = "tugaspraktik"
        Text = "tugaspraktik"
        CType(ErrorProvider1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblNama As Label
    Friend WithEvents lblNisn As Label
    Friend WithEvents lblUsia As Label
    Friend WithEvents lblEmail As Label
    Friend WithEvents btnDaftar As Button
    Friend WithEvents txtNama As TextBox
    Friend WithEvents txtNisn As TextBox
    Friend WithEvents txtUsia As TextBox
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents ErrorProvider1 As ErrorProvider
End Class
