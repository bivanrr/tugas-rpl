﻿Public Class Form5
    Private Sub btnCek_Click(sender As Object, e As EventArgs) Handles btnCek.Click

        ErrorProvider1.SetError(dtpTanggalLahir, "")
        lblUmur.Text = "-"

        Dim tanggalLahir As Date = dtpTanggalLahir.Value
        Dim tanggalSekarang As Date = DateTime.Now

        Dim tahun As Integer
        Dim bulan As Integer
        Dim hari As Integer

        Try
            If tanggalLahir.Year < 1900 OrElse tanggalLahir > tanggalSekarang Then
                Throw New ArgumentOutOfRangeException("Tanggal lahir harus berada di antara rentang 01/01/1900 sampai hari ini.")
            End If

            tahun = tanggalSekarang.Year - tanggalLahir.Year
            bulan = tanggalSekarang.Month - tanggalLahir.Month
            hari = tanggalSekarang.Day - tanggalLahir.Day

            If hari < 0 Then
                bulan -= 1
                Dim bulanSebelumnya As Date = tanggalSekarang.AddMonths(-1)
                hari += DateTime.DaysInMonth(bulanSebelumnya.Year, bulanSebelumnya.Month)
            End If

            If bulan < 0 Then
                tahun -= 1
                bulan += 12
            End If

            lblUmur.Text = $"{tahun} Tahun, {bulan} Bulan, {hari} Hari"
            lblUmur.ForeColor = Color.DarkGreen

        Catch ex As ArgumentOutOfRangeException
            ErrorProvider1.SetError(dtpTanggalLahir, ex.Message)
            lblUmur.Text = "Tanggal Tidak Valid"
            lblUmur.ForeColor = Color.Red
            dtpTanggalLahir.Focus()

        Catch ex As Exception
            MessageBox.Show($"Terjadi kesalahan sistem: {ex.Message}", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Finally
            Console.WriteLine("Kalkulasi umur dengan DateTimePicker selesai.")
        End Try
    End Sub

End Class