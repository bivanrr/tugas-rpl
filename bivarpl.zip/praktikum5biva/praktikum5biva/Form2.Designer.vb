﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnHitung = New Button()
        lblCelcius = New Label()
        lblHasil = New Label()
        txtCelcius = New TextBox()
        SuspendLayout()
        ' 
        ' btnHitung
        ' 
        btnHitung.Location = New Point(338, 196)
        btnHitung.Name = "btnHitung"
        btnHitung.Size = New Size(75, 23)
        btnHitung.TabIndex = 0
        btnHitung.Text = "Hitung"
        btnHitung.UseVisualStyleBackColor = True
        ' 
        ' lblCelcius
        ' 
        lblCelcius.AutoSize = True
        lblCelcius.Location = New Point(314, 149)
        lblCelcius.Name = "lblCelcius"
        lblCelcius.Size = New Size(45, 15)
        lblCelcius.TabIndex = 1
        lblCelcius.Text = "Celcius"
        ' 
        ' lblHasil
        ' 
        lblHasil.AutoSize = True
        lblHasil.Location = New Point(314, 235)
        lblHasil.Name = "lblHasil"
        lblHasil.Size = New Size(39, 15)
        lblHasil.TabIndex = 2
        lblHasil.Text = "Hasil :"
        ' 
        ' txtCelcius
        ' 
        txtCelcius.Location = New Point(314, 167)
        txtCelcius.Name = "txtCelcius"
        txtCelcius.Size = New Size(125, 23)
        txtCelcius.TabIndex = 3
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txtCelcius)
        Controls.Add(lblHasil)
        Controls.Add(lblCelcius)
        Controls.Add(btnHitung)
        Name = "Form2"
        Text = "Form2"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnHitung As Button
    Friend WithEvents lblCelcius As Label
    Friend WithEvents lblHasil As Label
    Friend WithEvents txtCelcius As TextBox
End Class
