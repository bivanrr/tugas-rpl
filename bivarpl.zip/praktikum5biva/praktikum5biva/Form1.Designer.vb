﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        btnHitung = New Button()
        btnReset = New Button()
        cmbTujuan = New ComboBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        lblTotal = New Label()
        txtBerat = New TextBox()
        SuspendLayout()
        ' 
        ' btnHitung
        ' 
        btnHitung.Location = New Point(371, 274)
        btnHitung.Name = "btnHitung"
        btnHitung.Size = New Size(110, 23)
        btnHitung.TabIndex = 0
        btnHitung.Text = "Hitung Ongkos"
        btnHitung.UseVisualStyleBackColor = True
        ' 
        ' btnReset
        ' 
        btnReset.Location = New Point(381, 303)
        btnReset.Name = "btnReset"
        btnReset.Size = New Size(75, 23)
        btnReset.TabIndex = 1
        btnReset.Text = "Reset"
        btnReset.UseVisualStyleBackColor = True
        ' 
        ' cmbTujuan
        ' 
        cmbTujuan.FormattingEnabled = True
        cmbTujuan.Location = New Point(262, 220)
        cmbTujuan.Name = "cmbTujuan"
        cmbTujuan.Size = New Size(121, 23)
        cmbTujuan.TabIndex = 2
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(262, 130)
        Label1.Name = "Label1"
        Label1.Size = New Size(88, 15)
        Label1.TabIndex = 3
        Label1.Text = "Berat Paket(Kg)"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(262, 202)
        Label2.Name = "Label2"
        Label2.Size = New Size(108, 15)
        Label2.TabIndex = 4
        Label2.Text = "Tujuan Pengiriman"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(480, 130)
        Label3.Name = "Label3"
        Label3.Size = New Size(79, 15)
        Label3.TabIndex = 5
        Label3.Text = "Ongkos Kirim"
        ' 
        ' lblTotal
        ' 
        lblTotal.AutoSize = True
        lblTotal.Location = New Point(480, 156)
        lblTotal.Name = "lblTotal"
        lblTotal.Size = New Size(27, 15)
        lblTotal.TabIndex = 6
        lblTotal.Text = "Rp :"
        ' 
        ' txtBerat
        ' 
        txtBerat.Location = New Point(262, 148)
        txtBerat.Name = "txtBerat"
        txtBerat.Size = New Size(121, 23)
        txtBerat.TabIndex = 7
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txtBerat)
        Controls.Add(lblTotal)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(cmbTujuan)
        Controls.Add(btnReset)
        Controls.Add(btnHitung)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnHitung As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents cmbTujuan As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents txtBerat As TextBox
End Class
