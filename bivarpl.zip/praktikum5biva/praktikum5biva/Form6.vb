﻿Imports System.Text.RegularExpressions

Public Class Form6
    Private Sub btnDaftar_Click(sender As Object, e As EventArgs) Handles btnDaftar.Click
        ErrorProvider1.Clear()
        Dim nama As String = txtNama.Text.Trim()
        Dim strNISN As String = txtNisn.Text.Trim()
        Dim strUsia As String = txtUsia.Text.Trim()
        Dim email As String = txtEmail.Text.Trim()
        Dim usia As Integer
        Dim isSemuaValid As Boolean = True

        Try
            If String.IsNullOrEmpty(nama) Then
                ErrorProvider1.SetError(txtNama, "Nama lengkap wajib diisi!")
                isSemuaValid = False
            End If

            If String.IsNullOrEmpty(strNISN) Then
                ErrorProvider1.SetError(txtNisn, "NISN wajib diisi!")
                isSemuaValid = False
            ElseIf Not Regex.IsMatch(strNISN, "^\d{10}$") Then
                ErrorProvider1.SetError(txtNisn, "NISN harus terdiri dari tepat 10 digit angka!")
                isSemuaValid = False
            End If

            If String.IsNullOrEmpty(strUsia) Then
                ErrorProvider1.SetError(txtUsia, "Usia wajib diisi!")
                isSemuaValid = False
            ElseIf Not Integer.TryParse(strUsia, usia) Then
                ErrorProvider1.SetError(txtUsia, "Usia harus berupa angka bulat!")
                isSemuaValid = False
            Else
                usia = Convert.ToInt32(strUsia)
                If usia < 10 OrElse usia > 20 Then
                    ErrorProvider1.SetError(txtUsia, "Usia harus berada di antara 10 hingga 20 tahun!")
                    isSemuaValid = False
                End If
            End If

            Dim emailPattern As String = "^[^@\s]+@[^@\s]+\.[^@\s]+$"
            If String.IsNullOrEmpty(email) Then
                ErrorProvider1.SetError(txtEmail, "Email wajib diisi!")
                isSemuaValid = False
            ElseIf Not Regex.IsMatch(email, emailPattern) Then
                ErrorProvider1.SetError(txtEmail, "Format email tidak valid! (Contoh: siswa@sekolah.com)")
                isSemuaValid = False
            End If

            If isSemuaValid Then
                MessageBox.Show("Pendaftaran berhasil!", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information)
                ClearForm()
            Else
                Throw New FormatException("Beberapa data yang Anda masukkan belum sesuai kriteria.")
            End If

        Catch ex As FormatException
            MessageBox.Show(ex.Message, "Peringatan Validasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)

        Catch ex As Exception
            MessageBox.Show($"Terjadi kesalahan fatal pada sistem: {ex.Message}", "System Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Finally
            Console.WriteLine("Pemeriksaan formulir pendaftaran selesai.")
        End Try

    End Sub

    Private Sub ClearForm()
        txtNama.Clear()
        txtNisn.Clear()
        txtUsia.Clear()
        txtEmail.Clear()
        txtNama.Focus()
    End Sub
End Class