﻿Public Class Form3
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim username As String
        Dim password As String

        Try
            username = txtUsername.Text.Trim()
            password = txtPassword.Text.Trim()

            'Validasi userna me
            If username = "" Then
                MessageBox.Show("Username tidak boleh kosong!",
                            "Peringatan",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning)
                txtUsername.Focus()
                Return
            End If

            'Validasi password
            If password = "" Then
                MessageBox.Show("Password tidak boleh kosong!",
                            "Peringatan",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning)
                txtPassword.Focus()
                Return
            End If

            'Pengecekan login
            If username = "rifa hisbha" AndAlso password = "228264" Then
                MessageBox.Show("Login berhasil!",
                            "Sukses",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information)
            Else
                MessageBox.Show("Username atau password salah!",
                            "Login Gagal",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show("Terjadi kesalahan: " & ex.Message,
                        "Error",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error)

        Finally
            MessageBox.Show("Percobaan login selesai",
                        "Info",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information)
        End Try

    End Sub

End Class