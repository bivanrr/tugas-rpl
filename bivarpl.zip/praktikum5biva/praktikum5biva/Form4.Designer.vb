﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnHitung = New Button()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        lblHasil = New Label()
        txtNilai1 = New TextBox()
        txtNilai2 = New TextBox()
        txtNilai3 = New TextBox()
        txtNilai4 = New TextBox()
        txtNilai5 = New TextBox()
        SuspendLayout()
        ' 
        ' btnHitung
        ' 
        btnHitung.Location = New Point(446, 230)
        btnHitung.Name = "btnHitung"
        btnHitung.Size = New Size(84, 36)
        btnHitung.TabIndex = 0
        btnHitung.Text = "Hitung"
        btnHitung.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(418, 93)
        Label1.Name = "Label1"
        Label1.Size = New Size(40, 15)
        Label1.TabIndex = 1
        Label1.Text = "Nilai 1"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(418, 122)
        Label2.Name = "Label2"
        Label2.Size = New Size(40, 15)
        Label2.TabIndex = 2
        Label2.Text = "Nilai 2"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(418, 151)
        Label3.Name = "Label3"
        Label3.Size = New Size(40, 15)
        Label3.TabIndex = 3
        Label3.Text = "Nilai 3"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(418, 180)
        Label4.Name = "Label4"
        Label4.Size = New Size(40, 15)
        Label4.TabIndex = 4
        Label4.Text = "Nilai 4"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(418, 209)
        Label5.Name = "Label5"
        Label5.Size = New Size(40, 15)
        Label5.TabIndex = 5
        Label5.Text = "Nilai 5"
        ' 
        ' lblHasil
        ' 
        lblHasil.AutoSize = True
        lblHasil.Location = New Point(418, 279)
        lblHasil.Name = "lblHasil"
        lblHasil.Size = New Size(39, 15)
        lblHasil.TabIndex = 6
        lblHasil.Text = "Hasil :"
        ' 
        ' txtNilai1
        ' 
        txtNilai1.Location = New Point(491, 85)
        txtNilai1.Name = "txtNilai1"
        txtNilai1.Size = New Size(131, 23)
        txtNilai1.TabIndex = 7
        ' 
        ' txtNilai2
        ' 
        txtNilai2.Location = New Point(491, 114)
        txtNilai2.Name = "txtNilai2"
        txtNilai2.Size = New Size(131, 23)
        txtNilai2.TabIndex = 8
        ' 
        ' txtNilai3
        ' 
        txtNilai3.Location = New Point(491, 143)
        txtNilai3.Name = "txtNilai3"
        txtNilai3.Size = New Size(131, 23)
        txtNilai3.TabIndex = 9
        ' 
        ' txtNilai4
        ' 
        txtNilai4.Location = New Point(491, 172)
        txtNilai4.Name = "txtNilai4"
        txtNilai4.Size = New Size(131, 23)
        txtNilai4.TabIndex = 10
        ' 
        ' txtNilai5
        ' 
        txtNilai5.Location = New Point(491, 201)
        txtNilai5.Name = "txtNilai5"
        txtNilai5.Size = New Size(131, 23)
        txtNilai5.TabIndex = 11
        ' 
        ' Form4
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txtNilai5)
        Controls.Add(txtNilai4)
        Controls.Add(txtNilai3)
        Controls.Add(txtNilai2)
        Controls.Add(txtNilai1)
        Controls.Add(lblHasil)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(btnHitung)
        Name = "Form4"
        Text = "Form4"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnHitung As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblHasil As Label
    Friend WithEvents txtNilai1 As TextBox
    Friend WithEvents txtNilai2 As TextBox
    Friend WithEvents txtNilai3 As TextBox
    Friend WithEvents txtNilai4 As TextBox
    Friend WithEvents txtNilai5 As TextBox
End Class
