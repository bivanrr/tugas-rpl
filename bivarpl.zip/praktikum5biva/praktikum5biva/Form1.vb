﻿Public Class Form1
    Private Sub btnHitung_Click(sender As Object, e As EventArgs) Handles btnHitung.Click
        Dim berat As Double
        Dim tarifDasar As Integer
        Dim biayaTujuan As Integer
        Dim totalOngkos As Integer

        If Not Double.TryParse(txtBerat.Text, berat) Then
            MessageBox.Show("Masukkan berat dengan angka yang benar!")
            txtBerat.Focus()
            Exit Sub
        End If

        If berat <= 0 Then
            MessageBox.Show("Berat paket harus lebih dari 0 kg!")
            txtBerat.Focus()
            Exit Sub
        End If
        If cmbTujuan.SelectedIndex = -1 Then
            MessageBox.Show("Silakan pilih tujuan pengiriman!")
            Exit Sub
            tarifDasar = 9000
        ElseIf berat <= 5 Then
            tarifDasar = 18000
        Else
            tarifDasar = 30000
        End If

        If cmbTujuan.Text = "Dalam Kota" Then
            biayaTujuan = 0

        ElseIf cmbTujuan.Text = "Luar Kota" Then
            biayaTujuan = 10000

        ElseIf cmbTujuan.Text = "Luar Pulau" Then
            biayaTujuan = 25000
        End If

        totalOngkos = tarifDasar + biayaTujuan

        lblTotal.Text = "Rp" & totalOngkos.ToString("N0")
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbTujuan.Items.Add("Dalam Kota")
        cmbTujuan.Items.Add("Luar Kota")
        cmbTujuan.Items.Add("Luar Pulau")
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtBerat.Clear()
        cmbTujuan.SelectedIndex = 0
        lblTotal.Text = "Rp0"
        txtBerat.Focus()
    End Sub
End Class
