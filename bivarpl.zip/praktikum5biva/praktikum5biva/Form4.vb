﻿Public Class Form4
    Private Sub btnHitung_Click(sender As Object, e As EventArgs) Handles btnHitung.Click
        Try
            Dim nilai1 As Double
            Dim nilai2 As Double
            Dim nilai3 As Double
            Dim nilai4 As Double
            Dim nilai5 As Double

            If Not Double.TryParse(txtNilai1.Text, nilai1) Then
                MessageBox.Show("Nilai 1 tidak valid!")
                Exit Sub
            End If

            If Not Double.TryParse(txtNilai2.Text, nilai2) Then
                MessageBox.Show("Nilai 2 tidak valid!")
                Exit Sub
            End If

            If Not Double.TryParse(txtNilai3.Text, nilai3) Then
                MessageBox.Show("Nilai 3 tidak valid!")
                Exit Sub
            End If

            If Not Double.TryParse(txtNilai4.Text, nilai4) Then
                MessageBox.Show("Nilai 4 tidak valid!")
                Exit Sub
            End If

            If Not Double.TryParse(txtNilai5.Text, nilai5) Then
                MessageBox.Show("Nilai 5 tidak valid!")
                Exit Sub
            End If

            Dim rataRata As Double

            rataRata = (nilai1 + nilai2 + nilai3 + nilai4 + nilai5) / 5

            lblHasil.Text = "Rata-rata = " & rataRata.ToString("0.00")

        Catch ex As FormatException
            MessageBox.Show("Format nilai tidak valid!")

        Catch ex As Exception
            MessageBox.Show("Terjadi kesalahan: " & ex.Message)

        Finally
            MessageBox.Show("Perhitungan selesai.")

        End Try
    End Sub
End Class