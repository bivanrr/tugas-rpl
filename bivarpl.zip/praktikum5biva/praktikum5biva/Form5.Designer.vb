﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Label1 = New Label()
        lblUmur = New Label()
        btnCek = New Button()
        dtpTanggalLahir = New DateTimePicker()
        ErrorProvider1 = New ErrorProvider(components)
        CType(ErrorProvider1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(315, 132)
        Label1.Name = "Label1"
        Label1.Size = New Size(84, 15)
        Label1.TabIndex = 0
        Label1.Text = "Tanggal Lahir :"
        ' 
        ' lblUmur
        ' 
        lblUmur.AutoSize = True
        lblUmur.Location = New Point(315, 205)
        lblUmur.Name = "lblUmur"
        lblUmur.Size = New Size(39, 15)
        lblUmur.TabIndex = 1
        lblUmur.Text = "Hasil :"
        ' 
        ' btnCek
        ' 
        btnCek.Location = New Point(363, 158)
        btnCek.Name = "btnCek"
        btnCek.Size = New Size(80, 26)
        btnCek.TabIndex = 3
        btnCek.Text = "Cek Umur"
        btnCek.UseVisualStyleBackColor = True
        ' 
        ' dtpTanggalLahir
        ' 
        dtpTanggalLahir.Location = New Point(405, 129)
        dtpTanggalLahir.Name = "dtpTanggalLahir"
        dtpTanggalLahir.Size = New Size(188, 23)
        dtpTanggalLahir.TabIndex = 4
        ' 
        ' ErrorProvider1
        ' 
        ErrorProvider1.ContainerControl = Me
        ' 
        ' Form5
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(dtpTanggalLahir)
        Controls.Add(btnCek)
        Controls.Add(lblUmur)
        Controls.Add(Label1)
        Name = "Form5"
        Text = "Form5"
        CType(ErrorProvider1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents lblUmur As Label
    Friend WithEvents btnCek As Button
    Friend WithEvents dtpTanggalLahir As DateTimePicker
    Friend WithEvents ErrorProvider1 As ErrorProvider
End Class
