﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        lblHasil = New Label()
        btnHitung = New Button()
        txtA = New TextBox()
        txtB = New TextBox()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(262, 160)
        Label1.Name = "Label1"
        Label1.Size = New Size(93, 15)
        Label1.TabIndex = 0
        Label1.Text = "Masukan Nilai A"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(263, 184)
        Label2.Name = "Label2"
        Label2.Size = New Size(92, 15)
        Label2.TabIndex = 1
        Label2.Text = "Masukan Nilai B"
        ' 
        ' lblHasil
        ' 
        lblHasil.AutoSize = True
        lblHasil.Location = New Point(283, 295)
        lblHasil.Name = "lblHasil"
        lblHasil.Size = New Size(33, 15)
        lblHasil.TabIndex = 2
        lblHasil.Text = "Hasil"
        ' 
        ' btnHitung
        ' 
        btnHitung.Location = New Point(395, 221)
        btnHitung.Name = "btnHitung"
        btnHitung.Size = New Size(100, 33)
        btnHitung.TabIndex = 3
        btnHitung.Text = "Hitung"
        btnHitung.UseVisualStyleBackColor = True
        ' 
        ' txtA
        ' 
        txtA.Location = New Point(371, 152)
        txtA.Name = "txtA"
        txtA.Size = New Size(159, 23)
        txtA.TabIndex = 4
        ' 
        ' txtB
        ' 
        txtB.Location = New Point(371, 181)
        txtB.Name = "txtB"
        txtB.Size = New Size(159, 23)
        txtB.TabIndex = 5
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txtB)
        Controls.Add(txtA)
        Controls.Add(btnHitung)
        Controls.Add(lblHasil)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblHasil As Label
    Friend WithEvents btnHitung As Button
    Friend WithEvents txtA As TextBox
    Friend WithEvents txtB As TextBox
End Class
