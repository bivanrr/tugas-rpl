﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnCek = New Button()
        Label1 = New Label()
        Label2 = New Label()
        lblHasil = New Label()
        txtA = New TextBox()
        txtB = New TextBox()
        SuspendLayout()
        ' 
        ' btnCek
        ' 
        btnCek.Location = New Point(385, 186)
        btnCek.Name = "btnCek"
        btnCek.Size = New Size(70, 32)
        btnCek.TabIndex = 0
        btnCek.Text = "Cek"
        btnCek.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(295, 120)
        Label1.Name = "Label1"
        Label1.Size = New Size(42, 15)
        Label1.TabIndex = 1
        Label1.Text = "Nilai A"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(295, 149)
        Label2.Name = "Label2"
        Label2.Size = New Size(41, 15)
        Label2.TabIndex = 2
        Label2.Text = "Nilai B"
        ' 
        ' lblHasil
        ' 
        lblHasil.AutoSize = True
        lblHasil.Location = New Point(246, 257)
        lblHasil.Name = "lblHasil"
        lblHasil.Size = New Size(33, 15)
        lblHasil.TabIndex = 3
        lblHasil.Text = "Hasil"
        ' 
        ' txtA
        ' 
        txtA.Location = New Point(351, 117)
        txtA.Name = "txtA"
        txtA.Size = New Size(145, 23)
        txtA.TabIndex = 4
        ' 
        ' txtB
        ' 
        txtB.Location = New Point(351, 146)
        txtB.Name = "txtB"
        txtB.Size = New Size(145, 23)
        txtB.TabIndex = 5
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txtB)
        Controls.Add(txtA)
        Controls.Add(lblHasil)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(btnCek)
        Name = "Form2"
        Text = "Form2"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnCek As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblHasil As Label
    Friend WithEvents txtA As TextBox
    Friend WithEvents txtB As TextBox
End Class
