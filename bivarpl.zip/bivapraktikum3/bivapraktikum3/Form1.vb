﻿Public Class Form1
    Private Sub btnHitung_Click(sender As Object, e As EventArgs) Handles btnHitung.Click
        Dim a As Integer = CInt(txtA.Text)
        Dim b As Integer = CInt(txtB.Text)
        Dim hasil As Integer
        hasil = a * b + (a - b) / a
        lblHasil.Text = "Hasil : " & hasil
    End Sub
End Class
