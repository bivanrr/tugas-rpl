﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class tugaspraktil3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        cmbMataUang = New ComboBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        btnKonversi = New Button()
        txtRupiah = New TextBox()
        txtHasil = New TextBox()
        btnReset = New Button()
        SuspendLayout()
        ' 
        ' cmbMataUang
        ' 
        cmbMataUang.FormattingEnabled = True
        cmbMataUang.Location = New Point(300, 179)
        cmbMataUang.Name = "cmbMataUang"
        cmbMataUang.Size = New Size(224, 23)
        cmbMataUang.TabIndex = 0
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(220, 153)
        Label1.Name = "Label1"
        Label1.Size = New Size(44, 15)
        Label1.TabIndex = 1
        Label1.Text = "Rupiah"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(220, 182)
        Label2.Name = "Label2"
        Label2.Size = New Size(64, 15)
        Label2.TabIndex = 2
        Label2.Text = "Mata uang"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(220, 211)
        Label3.Name = "Label3"
        Label3.Size = New Size(33, 15)
        Label3.TabIndex = 3
        Label3.Text = "Hasil"
        ' 
        ' btnKonversi
        ' 
        btnKonversi.Location = New Point(300, 253)
        btnKonversi.Name = "btnKonversi"
        btnKonversi.Size = New Size(75, 23)
        btnKonversi.TabIndex = 4
        btnKonversi.Text = "Konversi"
        btnKonversi.UseVisualStyleBackColor = True
        ' 
        ' txtRupiah
        ' 
        txtRupiah.Location = New Point(300, 150)
        txtRupiah.Name = "txtRupiah"
        txtRupiah.Size = New Size(224, 23)
        txtRupiah.TabIndex = 5
        ' 
        ' txtHasil
        ' 
        txtHasil.Location = New Point(297, 208)
        txtHasil.Name = "txtHasil"
        txtHasil.Size = New Size(227, 23)
        txtHasil.TabIndex = 6
        ' 
        ' btnReset
        ' 
        btnReset.Location = New Point(449, 253)
        btnReset.Name = "btnReset"
        btnReset.Size = New Size(75, 23)
        btnReset.TabIndex = 7
        btnReset.Text = "Reset"
        btnReset.UseVisualStyleBackColor = True
        ' 
        ' tugaspraktil3
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(884, 405)
        Controls.Add(btnReset)
        Controls.Add(txtHasil)
        Controls.Add(txtRupiah)
        Controls.Add(btnKonversi)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(cmbMataUang)
        Name = "tugaspraktil3"
        Text = "tugaspraktil3"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents cmbMataUang As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btnKonversi As Button
    Friend WithEvents txtRupiah As TextBox
    Friend WithEvents txtHasil As TextBox
    Friend WithEvents btnReset As Button
End Class
