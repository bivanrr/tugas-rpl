﻿Public Class Form3
    Private Sub btnProses_Click(sender As Object, e As EventArgs) Handles btnProses.Click
        Dim x As Boolean = chkX.Checked
        Dim y As Boolean = chkY.Checked
        Dim z As String
        If x And y Then
            z = "keduanya true"
        ElseIf x Or y Then
            z = "salah satu true"
        Else
            z = "keduanya false"
        End If
        lblHasil.Text = z
    End Sub
End Class