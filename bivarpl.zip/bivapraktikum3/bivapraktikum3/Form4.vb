﻿Public Class Form4
    Private Sub btnHitung_Click(sender As Object, e As EventArgs) Handles btnHitung.Click
        Dim a As Integer = CInt(txtNilai.Text)
        a += 20     'a = a + 20
        a *= 5      ' a = a * 5
        a -= 8      ' a= a - 8
        a = a Mod 9   ' sisa bagi 9
        lblHasil.Text = "Hasil : " & a
    End Sub
End Class