﻿Public Class tugaspraktil3
    Private Sub tugaspraktil3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbMataUang.Items.Add("USD")
        cmbMataUang.Items.Add("EUR")
        cmbMataUang.Items.Add("JPY")

    End Sub

    Private Sub btnKonversi_Click(sender As Object, e As EventArgs) Handles btnKonversi.Click
        Dim rupiah As Integer
        Dim hasil As Double
        rupiah = CInt(txtRupiah.Text)
        Select Case cmbMataUang.Text
            Case "USD"
                hasil = rupiah / 15500
            Case "EUR"
                hasil = rupiah / 17300
            Case "JPY"
                hasil = rupiah / 110
        End Select
        txtHasil.Text = FormatNumber(hasil, 2)
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtRupiah.Clear()
        txtHasil.Clear()
        cmbMataUang.SelectedIndex = 0
        txtRupiah.Focus()
    End Sub
End Class