﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        txtA = New TextBox()
        txtB = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        btnHitung = New Button()
        lblHasil = New Label()
        SuspendLayout()
        ' 
        ' txtA
        ' 
        txtA.Location = New Point(320, 136)
        txtA.Name = "txtA"
        txtA.Size = New Size(139, 23)
        txtA.TabIndex = 0
        ' 
        ' txtB
        ' 
        txtB.Location = New Point(320, 165)
        txtB.Name = "txtB"
        txtB.Size = New Size(141, 23)
        txtB.TabIndex = 1
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(221, 139)
        Label1.Name = "Label1"
        Label1.Size = New Size(93, 15)
        Label1.TabIndex = 2
        Label1.Text = "Masukan Nilai A"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(222, 168)
        Label2.Name = "Label2"
        Label2.Size = New Size(92, 15)
        Label2.TabIndex = 3
        Label2.Text = "Masukan Nilai B"
        ' 
        ' btnHitung
        ' 
        btnHitung.Location = New Point(333, 205)
        btnHitung.Name = "btnHitung"
        btnHitung.Size = New Size(90, 29)
        btnHitung.TabIndex = 4
        btnHitung.Text = "Hitung"
        btnHitung.UseVisualStyleBackColor = True
        ' 
        ' lblHasil
        ' 
        lblHasil.AutoSize = True
        lblHasil.Location = New Point(185, 325)
        lblHasil.Name = "lblHasil"
        lblHasil.Size = New Size(36, 15)
        lblHasil.TabIndex = 5
        lblHasil.Text = "Hasil "
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(lblHasil)
        Controls.Add(btnHitung)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(txtB)
        Controls.Add(txtA)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtA As TextBox
    Friend WithEvents txtB As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnHitung As Button
    Friend WithEvents lblHasil As Label
End Class
